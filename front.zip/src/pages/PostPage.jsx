import React, { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  getPostByIdApi,
  getPostCommentsApi,
  getPostReactionsApi,
  setPostReactionApi,
  clearPostReactionApi,
} from '../features/posts/api';
import { useSelector } from 'react-redux';
import { selectAuthToken, selectAuthUser } from '../features/auth/selectors';
import ToggleSwitch from '../shared/ui/ToggleSwitch';
import './PostPage.css';

export default function PostPage() {
  const { id } = useParams();
  const token = useSelector(selectAuthToken);
  const me    = useSelector(selectAuthUser);
  const isAdmin = me?.role === 'admin';

  const [post, setPost] = useState(null);
  const [loadingPost, setLoadingPost] = useState(true);
  const [errorPost, setErrorPost] = useState(null);

  const [comments, setComments] = useState([]);
  const [loadingCom, setLoadingCom] = useState(true);
  const [errorCom, setErrorCom] = useState(null);

  const [likeCount, setLikeCount] = useState(0);
  const [dislikeCount, setDislikeCount] = useState(0);
  const [myReaction, setMyReaction] = useState(null);
  const [busyReact, setBusyReact] = useState(false);

  // локальний статус поста (UI only)
  const [postActive, setPostActive] = useState(true);

  const canModerateComments = isAdmin || (post && me?.id === post.authorId);

  useEffect(() => {
    let mounted = true;
    setLoadingPost(true);
    setErrorPost(null);
    (async () => {
      try {
        const p = await getPostByIdApi(id);
        if (!mounted) return;
        setPost(p);
        setPostActive((p?.status ?? 'active') === 'active');
      } catch (e) {
        if (mounted) setErrorPost(e.message || 'Failed to load post');
      } finally {
        if (mounted) setLoadingPost(false);
      }
    })();
    return () => { mounted = false; };
  }, [id]);

  useEffect(() => {
    let mounted = true;
    setLoadingCom(true);
    setErrorCom(null);
    (async () => {
      try {
        const list = await getPostCommentsApi(id);
        if (!mounted) return;
        // якщо у комента немає status — вважаємо active
        const norm = Array.isArray(list) ? list.map(c => ({ status: 'active', ...c })) : [];
        setComments(norm);
      } catch (e) {
        if (mounted) setErrorCom(e.message || 'Failed to load comments');
      } finally {
        if (mounted) setLoadingCom(false);
      }
    })();
    return () => { mounted = false; };
  }, [id]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const reacts = await getPostReactionsApi(id);
        if (!mounted) return;
        const likes = reacts.filter(r => r.type === 'like').length;
        const dislikes = reacts.filter(r => r.type === 'dislike').length;
        setLikeCount(likes);
        setDislikeCount(dislikes);
        const mine = me?.id ? reacts.find(r => r.authorId === me.id) : null;
        setMyReaction(mine?.type || null);
      } catch {}
    })();
    return () => { mounted = false; };
  }, [id, me?.id]);

  const nameByAuthorId = useMemo(() => {
    const map = new Map();
    if (me?.id) map.set(me.id, me.fullName || me.login || `User #${me.id}`);
    return map;
  }, [me]);

  async function handleLike(type) {
    if (!token) { alert('Sign in to react'); return; }
    if (busyReact) return;
    setBusyReact(true);
    try {
      if (myReaction === type) {
        await clearPostReactionApi(id, token);
        if (type === 'like') setLikeCount(c => Math.max(0, c - 1));
        else setDislikeCount(c => Math.max(0, c - 1));
        setMyReaction(null);
      } else if (myReaction === null) {
        await setPostReactionApi(id, type, token);
        if (type === 'like') setLikeCount(c => c + 1);
        else setDislikeCount(c => c + 1);
        setMyReaction(type);
      } else {
        await setPostReactionApi(id, type, token);
        if (type === 'like') {
          setLikeCount(c => c + 1);
          setDislikeCount(c => Math.max(0, c - 1));
        } else {
          setDislikeCount(c => c + 1);
          setLikeCount(c => Math.max(0, c - 1));
        }
        setMyReaction(type);
      }
    } catch (e) {
      alert(e.message || 'Failed to react');
    } finally {
      setBusyReact(false);
    }
  }

  function togglePostActive(next) {
    setPostActive(next);
    alert(`TODO: toggle POST #${post?.id} to ${next ? 'active' : 'inactive'} (admin)`);
  }

  function toggleCommentActive(cid, next) {
    setComments(prev => prev.map(c => c.id === cid ? { ...c, status: next ? 'active' : 'inactive' } : c));
    alert(`TODO: toggle COMMENT #${cid} to ${next ? 'active' : 'inactive'} ${isAdmin ? '(admin)' : '(post owner)'}`);
  }

  return (
    <div className="postpage">
      {loadingPost && <div className="postpage__state">Loading post…</div>}
      {errorPost && !loadingPost && <div className="postpage__state postpage__state--err">⚠ {errorPost}</div>}

      {!loadingPost && !errorPost && post && (
        <article className="postpage__card">
          <div className="postpage__titleRow">
            <h1 className="postpage__title">{post.title}</h1>

            {/* Статус поста: бачить адмін */}
            <div className="postpage__status">
              <span className={`pc-status ${postActive ? 'is-ok' : 'is-off'}`}>
                {postActive ? 'active' : 'inactive'}
              </span>
              {isAdmin && (
                <ToggleSwitch
                  checked={postActive}
                  onChange={togglePostActive}
                  label="Post"
                  title="Activate / Deactivate post (admin only, TODO backend)"
                />
              )}
            </div>
          </div>

          <div className="postpage__actions">
            <button
              className={`react-btn ${myReaction === 'like' ? 'is-active' : ''}`}
              onClick={() => handleLike('like')}
              disabled={busyReact}
              title="Like"
            >
              👍 <span className="react-btn__count">{likeCount}</span>
            </button>
            <button
              className={`react-btn ${myReaction === 'dislike' ? 'is-active' : ''}`}
              onClick={() => handleLike('dislike')}
              disabled={busyReact}
              title="Dislike"
            >
              👎 <span className="react-btn__count">{dislikeCount}</span>
            </button>
          </div>

          <div className="postpage__content">{post.content}</div>
        </article>
      )}

      <section className="postpage__comments">
        <h2 className="postpage__h2">Comments</h2>

        {loadingCom && <div className="postpage__state">Loading comments…</div>}
        {errorCom && !loadingCom && <div className="postpage__state postpage__state--err">⚠ {errorCom}</div>}

        {!loadingCom && !errorCom && comments.length === 0 && (
          <div className="postpage__state">No comments yet.</div>
        )}

        {!loadingCom && !errorCom && comments.length > 0 && (
          <ul className="postpage__clist">
            {comments.map((c) => {
              const name =
                nameByAuthorId.get(c.authorId) ||
                c.authorLogin ||
                c.authorFullName ||
                `User #${c.authorId}`;
              const isActive = (c.status ?? 'active') === 'active';
              return (
                <li key={c.id} className="comment">
                  <div className="comment__head">
                    <span className="comment__author">{name}</span>
                    <time className="comment__time" dateTime={c.createdAt}>
                      {new Date(c.createdAt).toLocaleString()}
                    </time>
                  </div>

                  {/* Статус комента + перемикач:
                      - бачить адмін
                      - або автор поста (звичайний юзер у власному пості) */}
                  <div className="comment__moder">
                    <span className={`pc-status ${isActive ? 'is-ok' : 'is-off'}`}>
                      {isActive ? 'active' : 'inactive'}
                    </span>
                    {canModerateComments && (
                      <ToggleSwitch
                        checked={isActive}
                        onChange={(next)=>toggleCommentActive(c.id, next)}
                        label="Comment"
                        title={isAdmin ? 'Admin can deactivate comment' : 'Post owner can deactivate comments'}
                      />
                    )}
                  </div>

                  <div className="comment__body">{c.content}</div>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
