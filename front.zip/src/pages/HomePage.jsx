import React, { useEffect, useMemo, useState, useRef } from 'react';
import PostCard from '../shared/PostCard';
import Pagination from '../shared/Pagination';
import { useSelector } from 'react-redux';
import { selectAuthUser, selectAuthToken } from '../features/auth/selectors';
import { fetchPostsApi, adminListPostsApi } from '../features/posts/api';
import { fetchCategoriesApi } from '../features/categories/api';
import './HomePage.css';

const SORT_OPTIONS  = [
  { value: 'date',  label: 'By date' },
  { value: 'likes', label: 'By likes' },
];
const ORDER_OPTIONS = [
  { value: 'desc', label: 'Desc' },
  { value: 'asc',  label: 'Asc'  },
];

export default function HomePage() {
  const me      = useSelector(selectAuthUser);
  const token   = useSelector(selectAuthToken);
  const isAdmin = me?.role === 'admin';

  // ---- Категорії
  const [categories, setCategories] = useState([]); // [{id,title}]
  // "Чернетка" вибору (те, що юзер клікає у дропдауні)
  const [pendingChecked, setPendingChecked] = useState([]); // number[]
  // "Застосовані" категорії — саме вони летять у бекенд
  const [catsFilter, setCatsFilter] = useState([]); // number[]

  // ---- Інші фільтри
  const [sort, setSort]     = useState('date');
  const [order, setOrder]   = useState('desc');
  const [limit, setLimit]   = useState(12);

  // ---- Дані стрічки
  const [items, setItems]   = useState([]);
  const [total, setTotal]   = useState(0);
  const [page,  setPage]    = useState(1);
  const [loading, setLoading] = useState(false);
  const [err, setErr]         = useState(null);

  // Щоб Apply тригерив перезавантаження навіть якщо page вже = 1
  const [refreshTick, setRefreshTick] = useState(0);
  const catDDRef = useRef(null);

  // завантаження категорій
  useEffect(() => {
    let abort = false;
    (async () => {
      try {
        const list = await fetchCategoriesApi();
        if (!abort) {
          const arr = Array.isArray(list) ? list : [];
          setCategories(arr);
          // перший рендер — жодних застосованих категорій
          setPendingChecked((prev) => prev ?? []);
        }
      } catch {
        if (!abort) setCategories([]);
      }
    })();
    return () => { abort = true; };
  }, []);

  // зручний заголовок для multi-select summary
  const selectedSummary = useMemo(() => {
    if (!pendingChecked.length) return 'Categories';
    const names = pendingChecked
      .map((id) => categories.find((c) => c.id === id)?.title)
      .filter(Boolean);
    if (names.length > 2) return `${names.slice(0, 2).join(', ')}… (+${names.length - 2})`;
    return names.join(', ');
  }, [pendingChecked, categories]);

  function toggleCat(id) {
    setPendingChecked((prev) => (
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    ));
  }

  // єдині параметри запиту (в них — САМЕ ЗАСТОСОВАНІ категорії)
  const params = useMemo(() => {
    const base = { page, limit, sort, order };
    if (catsFilter.length) base.categories = catsFilter;
    // refreshTick в params — щоб useEffect гарантовано реагував на Apply
    return { ...base, __t: refreshTick };
  }, [page, limit, sort, order, catsFilter, refreshTick]);

  // фетч стрічки
  useEffect(() => {
    let abort = false;
    (async () => {
      try {
        setLoading(true);
        setErr(null);

        const data = isAdmin
          ? await adminListPostsApi(
              // передаємо categories у адмін-ендпойнт
              (catsFilter.length ? { ...params, categories: catsFilter } : params),
              token
            )
          : await fetchPostsApi({
              ...params,
              status: 'active',
              ...(catsFilter.length ? { categories: catsFilter } : {}),
            });

        if (abort) return;

        const list = Array.isArray(data?.items)
          ? data.items
          : (Array.isArray(data) ? data : []);

        setItems(list);
        setTotal(Number(data?.total ?? list.length));
        if (Number.isFinite(data?.limit)) setLimit(Number(data.limit));
      } catch (e) {
        if (!abort) {
          setItems([]);
          setTotal(0);
          setErr(e?.message || 'Failed to load posts');
        }
      } finally {
        if (!abort) setLoading(false);
      }
    })();
    return () => { abort = true; };
  }, [isAdmin, token, params, catsFilter]);

  // APPLY — переносимо "чернеткові" категорії у застосовані, скидаємо сторінку
  function handleApply() {
    setCatsFilter(pendingChecked);
    if (page !== 1) {
      setPage(1);
    } else {
      // якщо вже на 1-й сторінці — форсим оновлення
      setRefreshTick((t) => t + 1);
    }
    // закриємо дропдаун
    try {
      const el = catDDRef.current;
      if (el) el.removeAttribute('open');
    } catch {}
  }

  return (
    <div className="home">
      <section className="home__panel">
        {/* ФІЛЬТРИ (в одну лінію) */}
        <div className="filters" role="region" aria-label="Feed filters">
          {/* Categories dropdown */}
          <details className="filters__dd" ref={catDDRef}>
            <summary className="filters__dd-btn">{selectedSummary}</summary>
            <div className="filters__dd-menu">
              {categories.length === 0 ? (
                <div className="filters__dd-empty">No categories.</div>
              ) : (
                categories.map((c) => (
                  <label key={c.id} className="filters__dd-item">
                    <input
                      type="checkbox"
                      checked={pendingChecked.includes(c.id)}
                      onChange={() => toggleCat(c.id)}
                    />
                    <span>#{c.title}</span>
                  </label>
                ))
              )}
            </div>
          </details>

          {/* Sort */}
          <div className="filters__group">
            <label className="filters__label">Sort</label>
            <select
              className="filters__select"
              value={sort}
              onChange={(e)=>{ setSort(e.target.value); setPage(1); }}
            >
              {SORT_OPTIONS.map(o => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>

          {/* Order */}
          <div className="filters__group">
            <label className="filters__label">Order</label>
            <select
              className="filters__select"
              value={order}
              onChange={(e)=>{ setOrder(e.target.value); setPage(1); }}
            >
              {ORDER_OPTIONS.map(o => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>

          {/* Limit */}
          <div className="filters__group">
            <label className="filters__label">Per page</label>
            <input
              className="filters__number"
              type="number"
              min={3}
              max={30}
              value={limit}
              onChange={(e)=>{
                const v = Math.max(3, Math.min(30, Number(e.target.value) || 3));
                setLimit(v);
                setPage(1);
              }}
            />
          </div>

          {/* Apply */}
          <div className="filters__actions">
            <button type="button" className="filters__apply" onClick={handleApply} disabled={loading}>
              {loading ? '…' : 'Apply'}
            </button>
          </div>
        </div>

        {/* СПИСОК — ЛІНІЙКА */}
        <div className="home__list">
          {loading && <div className="home__state">Loading…</div>}
          {err && !loading && <div className="home__state home__state--err">⚠ {err}</div>}
          {!loading && !err && items.length === 0 && <div className="home__state">No posts.</div>}

          {!loading && !err && items.length > 0 && (
            <div className="home__col">
              {items.map(p => (
                <div className="home__item" key={p.id}>
                  <PostCard
                    post={p}
                    variant="line"
                    showDelete={isAdmin}
                    adminDelete={true}
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        <Pagination
          page={page}
          total={total}
          limit={limit}
          onPageChange={(p)=>setPage(p)}
        />
      </section>
    </div>
  );
}
