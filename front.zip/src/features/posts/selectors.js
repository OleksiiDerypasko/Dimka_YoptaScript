export const selectPostsItems   = (s) => s.posts.items;
export const selectPostsLoading = (s) => s.posts.loading;
export const selectPostsError   = (s) => s.posts.error;
export const selectPostsPage    = (s) => s.posts.page;
export const selectPostsTotal   = (s) => s.posts.total;
